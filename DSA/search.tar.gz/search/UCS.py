import heapq
import os
import time

# park_map = [
#     list("S...#....~....#.......#..."),
#     list(".###.#.#####.#.#####..#.#."),
#     list("...#.#.....#.#.....#..#.#."),
#     list(".#.#.###.#.#.#####.#.##.#."),
#     list(".#...~.#.#...^...#.#....#."),
#     list(".#####.#.#####.###.#######"),
#     list(".#.....#.....#.....#.....#"),
#     list(".#.#########.#####.#.###.#"),
#     list(".#.........#.....#.#...#.#"),
#     list(".#.#######.#####.#.###.#.#"),
#     list(".#.#.....#.....#.#...#.#.#"),
#     list(".#.#.###.#####.#.###.#.#.#"),
#     list(".#.#...#.....#.#.....#...#"),
#     list(".#.###.#####.#.#######.#.#"),
#     list("...#.....~...#.......~.#.E"),
# ]
park_map = [
    list("S......#....🌊....#..🐉🐉...⛰️...#"),
    list("..##..#.#.🌴🌴###.#.##⛰️🦁#..#.#.#"),
    list("...🌴#......🌴.🌴.....#..#.🌋....#"),
    list(".#.#.###.#.#.🦁🌳🦁🌳#.#.##.#....#"),
    list(".#..⛰️🌊...#...🌊⛰️..#.#....#....#"),
    list(".####⛰️.#..#🌳🌳🌴.###.#######...#"),
    list(".#..🌳..#.....🐉..#.#....🌴🌴....#"),
    list("....🌊.#.#🌳🌳##.###🌋..#.###....#"),
    list(".#....🌳🌳🦁🌳..#.....#.#...#....#"),
    list(".#.###🌳🌳##.🐉##🌋#.#.#.##.#.#..#"),
    list(".⛰️...#...#..🌋.#.#...#.#.🐉.🌋..#"),
    list(".🌴.#.#.#.##🌴🌴#.#.#🌊#...#.#...#"),
    list(".#.#...#..🌊.#..#...🌳🌳...🌳#...#"),
    list(".🌳.🌴🌴#..#🌊.#...#.#####.....#.."),
    list("...🌳.🌳.........🌳.....🌊..#....E"),
]
max_length = max(len(row) for row in park_map)
for row in park_map:
    row.extend([' '] * (max_length - len(row)))
    print(max_length)
    print(row)


cell_cost = {"S": 0, ".": 1, "🌳": 2,"🌴": 2, "⛰️": 10, "🌊":float("inf"),"#": float("inf"), "E": 0}

direction = [(1, 0), (-1, 0), (0, 1), (0, -1)]

 
def show(maze_map):
    os.system("cls" if os.name == "nt" else "clear")
    for row in maze_map:
        print(" ".join(row))


start = end = None

for x in range(len(park_map)):
    for y in range(len(park_map[0])):
        if park_map[x][y] == "S":
            start = (x, y)
        if park_map[x][y] == "E":
            end = (x, y)

heap = [(0, start, [])]
parent = {start: None}
cost_so_far = {start: 0}

while heap:
    cost, (row, col), path = heapq.heappop(heap)

    if park_map[row][col] not in ("S", "E"):
        park_map[row][col] = "*"

    show(park_map)
    time.sleep(0.1)

    if (row, col) == end:
        print("\nPath:", path + [(row, col)], "\nTotal cost:", cost)
        break

    for drow, dcol in direction:
        new_row, new_col = row + drow, col + dcol
        if 0 <= new_row < len(park_map) and 0 <= new_col < len(park_map[0]):
            cell = park_map[new_row][new_col]
            step_cost = cell_cost.get(cell, float("inf"))
            new_cost = cost + step_cost

            if step_cost != float("inf"):
                if (new_row, new_col) not in cost_so_far or new_cost < cost_so_far[
                    (new_row, new_col)
                ]:
                    cost_so_far[(new_row, new_col)] = new_cost
                    heapq.heappush(
                        heap, (new_cost, (new_row, new_col), path + [(row, col)])
                    )
                    parent[(new_row, new_col)] = (row, col)

# Reconstruct path
cost = 0
cur = end
while cur and cur != start:
    r, c = cur
    if park_map[r][c] not in ("S", "E"):
        park_map[r][c] = "@"
    cur = parent[cur]
    cost += 1

show(park_map)
print("\nFinal Path:")
print("total cost is  : ", cost)
