import os
import time
from collections import deque

# park_map Legend:
# S = Start
# E = End
# . or space = walkable path
# #, ⛰️, 🌊, 🌳, 🌴, 🦁, 🐉, 🌋 = blocks
park_map = [
    list("S......#....🌊🪨...#..🐉....🗻...#"),
    list("..##..#.#.🌴🌴....#.##⛰️🦁#..#.#.#"),
    list("...🌴#........🌴.....#..#.🌋....#"),
    list(".#.#.###.#.#.🌴🌳🦁🌳..#.##.#....#"),
    list(".#..🗻🌊...#...🌊⛰️..#.#....#....#"),
    list(".####⛰️.#..#🌳🌳🌴.#.#...#####...#"),
    list(".#..🌳..#.....🐉..#......🌴🌴....#"),
    list("....🌊.#.#🌳🌳##.###🌋..#.#.....##"),
    list(".#....🌳🌳🦁🌳..#.....#.....#....#"),
    list(".#.###🌳🌳##.🐉##🌋🗻.#.#.##.#.#..#"),
    list("..🗻......#..🌋.#.#...#.#.🐉.🌋..#"),
    list(".🌴...#.#.##🌴🌴#.#.#🌊#...#.#...#"),
    list(".#.#..#.....#..#...🌳🌳...🌳#...#"),
    list(".🌳..🌴#..#🌊.#.....#####.....#.."),
    list("...🌳.🌳.........🌳........#....E"),
]
# park_map = [
#     list("S  .  .  .  .  .  #  .  .  .  .  🌊 🪨 .   .  .  #  .  .  🐉 .  .  .  .  🗻 .  .  .  .  #"),
#     list(".  .  #  #  .  .  #  .  #  .  🌴 🌴 #  #   #  .  #  .  #  #  ⛰️ 🦁 #  .  .  #  .  #  .  #"),
#     list(".  .  . 🌴  #  .  .  .  .  .  🌴 .  .  .   .  .  .  .  #  .  .  #  .  🌋 .  .  .  .  .  #"),
#     list(".  #  .  #  .  #  #  #  .  #  .  #  .  🦁  🌳 🦁 🌳 .  .  #  .  #  #  .  #  .  .  .  .  #"),
#     list(".  #  .  .  🗻 🌊 .  .  .  #  .  .  .  🌊  ⛰️ .  .  #  .  #  .  .  .  .  #  .  .  .  .  #"),
#     list(".  #  #  #  #  ⛰️ .  #  .  .  #  🌳 🌳 🌴  .  #  #  #  .  .  .  #  #  #  #  #  .  .  .  #"),
#     list(".  #  .  .  🌳 .  .  #  .  .  .  .  .  🐉  .  .  .  #  .  #  .  .  .  .  🌴 🌴 .  .  .  #"),
#     list(".  .  .  .  🌊 .  #  .  #  .  🌳 🌳 #  #   .  #  #  #  🌋 .  .  #  .  #  #  #  .  .  .  #"),
#     list(".  #  .  .  .  .  🌳 🌳 🦁 🌳 .  .  #  .   .  .  .  .  #  .  #  .  .  .  .  #  .  .  .  #"),
#     list(".  #  .  .  #  #  🌳 🌳 #  #  .  🐉 #  #  🌋  🗻 .  #  .  #  .  #  #  .  #  .  #  .  .  #"),
#     list(".  .  🗻 .  .  #  .  .  .  #  .  .  🌋 .   #  .  #  .  .  .  .  .  #  .  🐉 .  🌋 .  .  #"),
#     list(".  🌴 .  #  .  #  .  #  .  #  #  .  🌴 🌴  #  .  #  .  #  🌊 #  .  .  .  #  .  #  .  .  #"),
#     list(".  #  .  .  .  .  .  .  .  .  .  .  #  .   .  #  .  .  .  🌳 🌳 .  .  .  🌳 #  .  .  .  #"),
#     list(".  🌳 .  . 🌴  #  #  .  #  🌊 .  #  .  .   .  .  .  #  #  #  #  #  .  .  .  .  #  .  .  #"),
#     list(".  .  .  🌳 .  🌳 .  .  .  .  .  .  .  .  🌳  .  .  .  .  .  .  #  .  .  .  .  .  .  .  E"),
# ]
# park_map= [
#     list("S...#..."),
#     list(".#.#.#.."),
#     list(".#.....#"),
#     list("###.#.#."),
#     list("...#...E"),
#     list(".#####.."),
# ]
#Pad shorter rows to match the longest row's length
max_length = max(len(row) for row in park_map)
for row in park_map:
    row.extend([' '] * (max_length - len(row)))
    print(max_length)
    print(row)


# Movement: up, down, left, right
direction = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def show(park_map):
    os.system("cls" if os.name == "nt" else "clear")
    for row in park_map:
        print("  ".join(row))

# Locate start (S) and end (E)
start = end = None
for x in range(len(park_map)):
    print("row : " ,x)
    for y in range(len(park_map[0])):
        print("colum : " ,y)
        print("error",x,y)
        if park_map[x][y] == "S":
            # print("error",x,y)
            start = (x, y)
        elif park_map[x][y] == "E":
            end = (x, y)

# Define blocked terrain (walls)
blocks = {"#", "🪨","⛰️", "🗻","🏔️","🌊", "🌳", "🌴", "🦁", "🐉", "🌋"}

# Breadth-First Search setup
queue = deque([start])
visited = {start}
parent = {start: None}

while queue:
    row, col = queue.popleft()

    if park_map[row][col] not in ("S", "E"):
        park_map[row][col] = "*"

    show(park_map)
    time.sleep(0.05)

    if (row, col) == end:
        break

    for drow, dcol in direction:
        new_row, new_col = row + drow, col + dcol
        inside_bounds = 0 <= new_row < len(park_map) and 0 <= new_col < len(park_map[0])
        new_pos = (new_row, new_col)

        if inside_bounds and park_map[new_row][new_col] not in blocks and new_pos not in visited:
            queue.append(new_pos)
            visited.add(new_pos)
            parent[new_pos] = (row, col)

# Reconstruct path
cost = 0
cur = end
while cur and cur != start:
    r, c = cur
    if park_map[r][c] not in ("S", "E"):
        park_map[r][c] = "@"
        cost += 1
    cur = parent[cur]

# Final Maze Display
show(park_map)
print(max_length)
# print(row)
print("\n✅ Final Path Found!")
print("📍 Total Cost: ", cost)
