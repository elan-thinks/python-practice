import os
import time

park_map = [
    list("S......#....🌊🪨...#..🐉....🗻...#"),
    list("..##..#.#.🌴🌴....#.##⛰️🦁#..#.#.#"),
    list("...🌴#........🌴.....#..#.🌋....#"),
    list(".#.#.###.#.#.🌴🌳🦁🌳..#.##.#....#"),
    list(".#..🗻🌊...#...🌊⛰️..#.#....#....#"),
    list(".####⛰️.#..#🌳🌳🌴.#.#...#####...#"),
    list(".#..🌳..#.....🐉..#......🌴🌴....#"),
    list("....🌊.#.#🌳🌳##.###🌋..#.#.....##"),
    list(".#....🌳🌳🦁🌳..#.....#.....#....#"),
    list(".#.###🌳🌳##.🐉##🌋🗻.#.#.##.#.#..#"),
    list("..🗻......#..🌋.#.#...#.#.🐉.🌋..#"),
    list(".🌴...#.#.##🌴🌴#.#.#🌊#...#.#...#"),
    list(".#.#..#.....#..#...🌳🌳...🌳#...#"),
    list(".🌳..🌴#..#🌊.#.....#####.....#.."),
    list("...🌳.🌳.........🌳........#....E"),
]

# Movement directions: up, down, left, right
direction = [(-1, 0), (1, 0), (0, -1), (0, 1)]

def show(maze_map):
    os.system("cls" if os.name == "nt" else "clear")
    for row in maze_map:
        print(" ".join(row))

# Find start (S) and end (E) positions
start = end = None
for x in range(len(park_map)):
    for y in range(len(park_map[0])):
        if park_map[x][y] == "S":
            start = (x, y)
        elif park_map[x][y] == "E":
            end = (x, y)

# Define costs for different terrain types
cell_cost = {
    "S": 0, ".": 1, 
    "🌳": 2, "🌴": 2, "⛰️": 10, 
    "🌊": float("inf"), "#": float("inf"), 
    "E": 0, "🪨": float("inf"), "🗻": float("inf"),
    "🦁": float("inf"), "🐉": float("inf"), "🌋": float("inf")
}

# DFS setup
stack = [start]
visited = {start}
parent = {start: None}

while stack:
    row, col = stack.pop()

    if park_map[row][col] not in ("S", "E"):
        park_map[row][col] = "*"

    show(park_map)
    time.sleep(0.1)

    if (row, col) == end:
        print("Reached the End!")
        break

    for drow, dcol in direction:
        new_row, new_col = row + drow, col + dcol
        inside = 0 <= new_row < len(park_map) and 0 <= new_col < len(park_map[0])
        new_pos = (new_row, new_col)
        
        if inside and new_pos not in visited:
            cell = park_map[new_row][new_col]
            if cell in cell_cost and cell_cost[cell] != float("inf"):
                stack.append(new_pos)
                visited.add(new_pos)
                parent[new_pos] = (row, col)

# Reconstruct path
cost = 0
cur = end
while cur and cur != start:
    r, c = cur
    if park_map[r][c] not in ("S", "E"):
        park_map[r][c] = "@"
        # Add the cost of the current cell to the total
        cell = park_map[r][c]
        cost += cell_cost.get(park_map[r][c], 1)  # Default to 1 if not found
    cur = parent.get(cur, None)

# Final display
show(park_map)
print("\nFinal Path Found!")
print("Total cost:", cost)
